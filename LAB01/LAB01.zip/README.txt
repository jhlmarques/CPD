Por: Eduarda Carvalho Waechter e José Henrique Lima Marques

O programa principal está contido no arquivo main.py. O arquivo shellsortinput.py contém
a definição da classe ShellSortInput, utilizada para extrair os dados do arquivo de entrada.